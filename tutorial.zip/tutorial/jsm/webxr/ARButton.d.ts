import {
	WebGLRenderer
} from '../../../src/Three';

export namespace ARButton {
	export function createButton( renderer: WebGLRenderer, sessionInit?: any ): HTMLElement;
}
